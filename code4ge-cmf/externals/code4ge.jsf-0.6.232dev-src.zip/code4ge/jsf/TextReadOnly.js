define("code4ge/jsf/TextReadOnly", [
	'dojo',
	'dijit',
	'code4ge/jsf/_Widget',
	'dijit/_Templated'
], function(dojo, dijit) {

dojo.declare('code4ge.jsf.TextReadOnly', [ code4ge.jsf._Widget, dijit._Templated ], {

	templateString: '<div dojoAttachPoint="_text" style="overflow:auto"></div>',

	_setValueAttr: function(/*any*/value) {

		this._text.innerHTML = value;
	},

	_getValueAttr: function() {

		return this._text.innerHTML;
	},

	resize: function(/*object*/size) {

		if(size.w) {
			dojo.style(this._text, 'width', size.w + 'px');
		}
		if(size.h) {
			dojo.style(this._text, 'height', size.h + 'px');
		}
	}

});

return code4ge.jsf.TextReadOnly;
});
