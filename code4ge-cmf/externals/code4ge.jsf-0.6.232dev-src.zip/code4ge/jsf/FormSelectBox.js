define("code4ge/jsf/FormSelectBox", [
	'dojo',
	'dijit',
	'code4ge/jsf/_FormElement',
	'code4ge/jsf/FilteringSelect',
	'text!code4ge/jsf/templates/FormSelectBox.html'
], function(dojo, dijit) {

dojo.declare('code4ge.jsf.FormSelectBox', [ code4ge.jsf._FormElement ], {

	templateString: dojo.cache('code4ge.jsf', 'templates/FormSelectBox.html'),

	inputClass: 'code4ge.jsf.FilteringSelect',

	maxlength: 20,

	// options defined in the markup
	_options: '',

	postMixInProperties: function() {

		this.inherited(arguments);

		// get options
		this._options = this.srcNodeRef ? this.srcNodeRef.innerHTML : null;

		// parse options if this is a select box and replace value with text
		if(this.readOnly) {
			this._fixValue();
		}
	},

	buildRendering: function() {

		this.inherited(arguments);

		this._fixFocus('.dijitArrowButtonInner', this._input);
	},

	_fixValue: function() {

		var node = dojo.create('div', {
			innerHTML: '<select>' + this._options + '</select>'
		});
		var select = node.firstChild;
		for(var i=0; i < select.length; i++) {
			var option = select.options[i];
			if(this.value == option.value) {
				this.value = option.text;
				break;
			}
		}
		delete node;
	}

});

return code4ge.jsf.FormSelectBox;
});
