define("code4ge/jsf/FilteringSelect", [
	'dojo',
	'dijit',
	'dijit/form/FilteringSelect'
], function(dojo, dijit) {

dojo.declare('code4ge.jsf.FilteringSelect', [ dijit.form.FilteringSelect ], {

	isValid: function() {

		return this.item && !(this.required && this.get('displayedValue')=='');
	}

});

return code4ge.jsf.FilteringSelect;
});
