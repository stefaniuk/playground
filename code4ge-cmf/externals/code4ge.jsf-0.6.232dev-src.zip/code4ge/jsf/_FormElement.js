define("code4ge/jsf/_FormElement", [
	'dojo',
	'dijit',
	'code4ge/jsf/_Widget',
	'dijit/_Templated',
	'code4ge/jsf/TextReadOnly'
], function(dojo, dijit) {

dojo.declare('code4ge.jsf._FormElement', [ code4ge.jsf._Widget, dijit._Templated ], {

	readOnlyTemplateString: dojo.cache('code4ge.jsf', 'templates/FormTextReadOnly.html'),

	widgetsInTemplate: true,

	labelOnTop: true,

	labelAlign: '',

	label: '',

	inputClass: '',

	name: '',

	value: '',

	labelWidth: '',

	inputWidth: '',

	multiline: false,

	promptMessage: '',

	invalidMessage: '',

	readOnly: false,

	readOnlyInputClass: 'code4ge.jsf.TextReadOnly',

	disabled: false,

	required: true,

	selectOnClick: true,

	trim: true,

	maxlength: 50,

	tabindex: 0,

	_linebreak: '<div class="form-break-line"></div>',

	postMixInProperties: function() {

		this.inherited(arguments);

		if(this.promptMessage) {
			this.promptMessage = 'promptMessage="' + this.promptMessage + '"';
		}

		if(this.invalidMessage) {
			this.invalidMessage = 'invalidMessage="' + this.invalidMessage + '"';
		}

		if(this.readOnly && this.readOnlyInputClass) {
			this.inputClass = this.readOnlyInputClass;
			this.templateString = this.readOnlyTemplateString;
		}

		if(!this.labelOnTop) {
			this._linebreak = '';
		}
	},

	buildRendering: function() {

		this.inherited(arguments);

		// set label location class
		dojo.addClass(this.domNode, this.labelOnTop ? 'form-widget-labelontop' : 'form-widget-labelonleft');

		// set label aligin
		if(!this.labelOnTop && this.labelAlign) {
			dojo.style(this._label, 'textAlign', this.labelAlign);
		}

		// do not wrap value if this is single line read-only widget
		if(this.readOnly && !this.multiline) {
			dojo.style(this._input._text, {
				'whiteSpace': 'nowrap',
				'overflow': 'hidden'
			});
		}
	},

	postCreate: function() {

		this.inherited(arguments);

		// call resize on ready
		dojo.connect(this, 'onReady', this, 'resize');

		// wire keyboard events
		if(this._input.onKeyPress) {
			dojo.connect(this._input, 'onKeyPress', this, function(event) {
				this.onEvent('onkeypress', event);
			});
		}
		if(this._input.onKeyUp) {
			dojo.connect(this._input, 'onKeyUp', this, function(event) {
				this.onEvent('onkeyup', event);
			});
		}
		if(this._input.onKeyUp) {
			dojo.connect(this._input, 'onChange', this, function(event) {
				this.onEvent('onchange', event);
			});
		}
	},

	resize: function() {

		// search for a grid class
		var gridClass = code4ge.hasClass(this.domNode, 'grid_');

		// set label width
		if(this.labelWidth) {
			dojo.style(this._label, 'width', parseInt(this.labelWidth) - 4 + 'px');
		}
		// set widget width
		if(this.inputWidth && !gridClass) {
			var w = dojo._getMarginSize(this._label).w + parseInt(this.inputWidth);
			if(w > 0) { // HACK: IE
				dojo.style(this.domNode, 'width', w + 'px');
			}
		}
		// set input width
		if(gridClass || this.inputWidth) {
			var w = dojo._getMarginSize(this.domNode).w;
			var lw = dojo._getMarginSize(this._label).w;
			var iw = w - (this.labelOnTop ? 0 : lw); // substract label
			// grid
			if(gridClass && !this.inputWidth) {
				// substract prefix and suffix
				iw = iw - dojo.style(this.domNode, 'paddingLeft') - dojo.style(this.domNode, 'paddingRight');
				// add 2px for single line read-only widget
				iw = iw + (this.readOnly && !this.multiline ? 2 : 0);
				// substract margin, border and padding from inside of an input node
				iw = iw - 22 - 2 * dojo.style(this._input.domNode, 'paddingLeft');
			}
			// no grid
			if(!gridClass && this.inputWidth) {
				iw = iw - (this.readOnly ? 0 : 2); // substract border
			}

			if(iw > 0) { // HACK: IE
				dojo.style(this._input.domNode, 'width', iw + 'px');
			}
		}
	},

	focus: function() {

		this._input.focus();
	},

	isValid: function() {

		var v = true;
		if(this._input.isValid) {
			v = this._input.isValid();
		}

		return v;
	},

	validate: function(/*boolean*/isFocused) {

		var v = true;
		if(this._input.validate) {
			v = this._input.validate(isFocused);
			// close pop-up box
			if(this._input._close) {
				var self = this;
				setTimeout(function() { self._input._close(); }, 10);
			}
		}

		return v;
	},

	reset: function() {

		this._input.reset();
	},

	_fixFocus: function(/*string*/query,/*domNode*/node) {

		if(dojo.isFF) {
			// HACK: in FF focus is lost after validation
			dojo.query(query, this.domNode).forEach(function(item) {
				dojo.connect(item, 'onfocus', function() {
					node.focusNode.focus();
				})
			});
		}
	},

	_setValueAttr: function(/*any*/value) {

		this._input.set('value', value);
	},

	_getValueAttr: function() {

		return this._input.get('value');
	},

	_setDisabledAttr: function(/*boolean*/disabled) {

		this._input.set('disabled', disabled);
	},

	_getDisabledAttr: function() {

		return this._input.get('disabled');
	},

	onEvent: function(type, event) {

	}

});

return code4ge.jsf._FormElement;
});
