define("code4ge/jsf/Grid", [
	'dojo',
	'dojox',
	'code4ge/jsf/_Widget',
	'dojox/grid/EnhancedGrid',
	'dojox/grid/enhanced/plugins/IndirectSelection',
	'dojox/grid/enhanced/plugins/Pagination',
	'code4ge/jsf/JsonRpcStore'
], function(dojo, dojox) {

dojo.declare('code4ge.jsf.Grid', [ code4ge.jsf._Widget, dojox.grid.EnhancedGrid ], {

	postMixInProperties: function() {

		if(dojo.isString(this.store)) {
			var registry = code4ge.get('jsonrpcstore.registry');
			this.store = registry.get(this.store);
		}

		this.inherited(arguments);
	}

});

return code4ge.jsf.Grid;
});
