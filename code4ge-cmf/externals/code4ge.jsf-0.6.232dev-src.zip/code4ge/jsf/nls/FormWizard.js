define({ root: 
//begin v1.x content
({
	previous: 'Previous',
	next: 'Next',
	send: 'Send'
})
//end v1.x content
,
"pl": true
});
