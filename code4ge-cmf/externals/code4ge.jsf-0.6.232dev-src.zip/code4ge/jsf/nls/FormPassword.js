define({ root: 
//begin v1.x content
({
	passwordsAreDiffrent: 'Given passwords are diffrent.'
})
//end v1.x content
,
"pl": true
});
