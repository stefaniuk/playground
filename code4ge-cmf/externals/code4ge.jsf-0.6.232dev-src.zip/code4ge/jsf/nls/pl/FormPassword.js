define(
//begin v1.x content
({
	passwordsAreDiffrent: 'Podane hasła się róznią.'
})
//end v1.x content
);
