define(
//begin v1.x content
({
	previous: 'Wstecz',
	next: 'Dalej',
	send: 'Wyślij'
})
//end v1.x content
);
