define(
//begin v1.x content
({
	edit: 'Edycja',
	preview: 'Podgląd'
})
//end v1.x content
);
