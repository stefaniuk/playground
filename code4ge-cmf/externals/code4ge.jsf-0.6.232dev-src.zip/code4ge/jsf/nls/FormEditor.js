define({ root: 
//begin v1.x content
({
	edit: 'Edit',
	preview: 'Preview'
})
//end v1.x content
,
"pl": true
});
