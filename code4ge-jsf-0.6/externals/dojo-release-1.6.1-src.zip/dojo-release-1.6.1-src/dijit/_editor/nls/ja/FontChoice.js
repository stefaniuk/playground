define(
//begin v1.x content
({
	fontSize: "サイズ",
	fontName: "フォント",
	formatBlock: "フォーマット",

	serif: "serif",
	"sans-serif": "sans-serif",
	monospace: "monospace",
	cursive: "cursive",
	fantasy: "fantasy",

	noFormat: "なし",
	p: "段落",
	h1: "見出し",
	h2: "副見出し",
	h3: "副見出しの副見出し",
	pre: "事前フォーマット済み",

	1: "超極小",
	2: "極小",
	3: "小",
	4: "標準",
	5: "大",
	6: "特大",
	7: "超特大"
})
//end v1.x content
);
