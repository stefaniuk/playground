define(
//begin v1.x content
({
	createLinkTitle: "คุณสมบัติลิงก์",
	insertImageTitle: "คุณสมบัติอิมเมจ",
	url: "URL:",
	text: "รายละเอียด:",
	target: "เป้าหมาย:",
	set: "ตั้งค่า",
	currentWindow: "หน้าต่างปัจจุบัน",
	parentWindow: "หน้าต่างหลัก",
	topWindow: "หน้าต่างบนสุด",
	newWindow: "หน้าต่างใหม่"
})

//end v1.x content
);
