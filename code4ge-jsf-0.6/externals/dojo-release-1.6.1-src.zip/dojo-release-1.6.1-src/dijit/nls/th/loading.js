define(
//begin v1.x content
({
	loadingState: "กำลังโหลด...",
	errorState: "ขออภัย เกิดข้อผิดพลาด"
})

//end v1.x content
);
