#!/bin/sh
# Make translation files
intltool-update -g terminator -o terminator.pot -p
