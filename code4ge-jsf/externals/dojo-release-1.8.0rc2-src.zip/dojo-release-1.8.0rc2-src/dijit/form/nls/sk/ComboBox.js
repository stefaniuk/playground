define(
({
		previousMessage: "Predchádzajúce možnosti",
		nextMessage: "Viac možností"
})
);
