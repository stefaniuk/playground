define(
//begin v1.x content
({
	buttonOk: "確定",
	buttonCancel: "取消",
	buttonSave: "儲存",
	itemClose: "關閉"
})
//end v1.x content
);
