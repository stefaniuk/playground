define(
//begin v1.x content
({
	createLinkTitle: "Сілтеме сипаттары",
	insertImageTitle: "Сурет сипаттары",
	url: "URL мекенжайы:",
	text: "Сипаттама:",
	target: "Мақсат:",
	set: "Орнату",
	currentWindow: "Ағымдағы терезе",
	parentWindow: "Басты терезе",
	topWindow: "Ең жоғарғы терезе",
	newWindow: "Жаңа терезе"
})
//end v1.x content
);
